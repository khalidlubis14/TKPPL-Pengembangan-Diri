Untuk Menjalankan Slide Presentasi, ketikkan perintah dibawah

npm start

Pastikan saat mengetikkan perintah kamu sudah berada di dalam directory Project
misal menggunakan GitBash, tinggal klik kanan saja di dalam Folder Root Project, lalu Pilih gitbash, dan ketikkan perintah diatas.

#TugasKelompokTKPPL_2020-2021